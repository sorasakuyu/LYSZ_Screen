--
-- PostgreSQL database dump
--

\restrict gkT8M6jp9xfbT0guBNnqMXoMeb7abAb9GXXKFBNf4N017tUmCH2lXxxOrWk2FAT

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.video DROP CONSTRAINT video_pkey;
ALTER TABLE ONLY public.renmindaily DROP CONSTRAINT renmindaily_pkey;
ALTER TABLE ONLY public.notice_text DROP CONSTRAINT notice_text_device_title_key;
ALTER TABLE ONLY public.notice_picture DROP CONSTRAINT notice_picture_pkey;
ALTER TABLE ONLY public.device_list DROP CONSTRAINT device_list_pkey;
ALTER TABLE ONLY public.days_master DROP CONSTRAINT days_master_pkey;
ALTER TABLE ONLY public.config DROP CONSTRAINT config_device_key_key;
ALTER TABLE public.renmindaily ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.days_master ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.video;
DROP SEQUENCE public.renmindaily_id_seq;
DROP TABLE public.renmindaily;
DROP TABLE public.notice_text;
DROP TABLE public.notice_picture;
DROP TABLE public.device_list;
DROP SEQUENCE public.days_master_id_seq;
DROP TABLE public.days_master;
DROP TABLE public.config;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.config (
    key text NOT NULL,
    value text NOT NULL,
    device text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.config OWNER TO postgres;

--
-- Name: days_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.days_master (
    id bigint NOT NULL,
    content text NOT NULL,
    "time" timestamp with time zone NOT NULL,
    device text DEFAULT 'default'::text NOT NULL
);


ALTER TABLE public.days_master OWNER TO postgres;

--
-- Name: days_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.days_master_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.days_master_id_seq OWNER TO postgres;

--
-- Name: days_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.days_master_id_seq OWNED BY public.days_master.id;


--
-- Name: device_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_list (
    device_id text NOT NULL,
    remark text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.device_list OWNER TO postgres;

--
-- Name: notice_picture; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notice_picture (
    device text NOT NULL,
    url text NOT NULL
);


ALTER TABLE public.notice_picture OWNER TO postgres;

--
-- Name: notice_text; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notice_text (
    device text DEFAULT 'default'::text NOT NULL,
    title text NOT NULL,
    context text NOT NULL
);


ALTER TABLE public.notice_text OWNER TO postgres;

--
-- Name: renmindaily; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.renmindaily (
    id integer NOT NULL,
    content text NOT NULL,
    defination text NOT NULL,
    theme text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.renmindaily OWNER TO postgres;

--
-- Name: renmindaily_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.renmindaily_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.renmindaily_id_seq OWNER TO postgres;

--
-- Name: renmindaily_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.renmindaily_id_seq OWNED BY public.renmindaily.id;


--
-- Name: video; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.video (
    device text NOT NULL,
    url text NOT NULL
);


ALTER TABLE public.video OWNER TO postgres;

--
-- Name: days_master id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.days_master ALTER COLUMN id SET DEFAULT nextval('public.days_master_id_seq'::regclass);


--
-- Name: renmindaily id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.renmindaily ALTER COLUMN id SET DEFAULT nextval('public.renmindaily_id_seq'::regclass);


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.config (key, value, device) FROM stdin;
mode	default	default
notice_mode	text	default
mode	default	6461EABC29C95D9E
notice_mode	text	6461EABC29C95D9E
\.


--
-- Data for Name: days_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.days_master (id, content, "time", device) FROM stdin;
1		2026-02-23 13:11:26.85999+08	default
2		2026-02-23 13:40:53.09862+08	6461EABC29C95D9E
\.


--
-- Data for Name: device_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_list (device_id, remark) FROM stdin;
default	测试设备
\.


--
-- Data for Name: notice_picture; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notice_picture (device, url) FROM stdin;
default	http://0.0.0.0/test/pic.jpg
\.


--
-- Data for Name: notice_text; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notice_text (device, title, context) FROM stdin;
default	通知	这是一条测试通知。
\.


--
-- Data for Name: renmindaily; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.renmindaily (id, content, defination, theme) FROM stdin;
2	险夷不变应尝胆，\n道义争担敢息肩。	无论境遇顺逆，都要如卧薪尝胆般坚守初心、磨砺心志；对于道义与责任，要主动承担、绝不推卸，尽显刚健有为、勇于担当的品格。	坚韧担当、时代使命
3	青山不语仍自在，\n微水无痕亦从容。	青山沉默不语，却始终保持自己的巍峨与生机；微水悄然流淌，亦维持着清澈从容的姿态。喻指人在纷扰中不必刻意彰显，只需守住内心的笃定与平和，便能自成境界。	淡泊宁静、坚守内心、不为外物所扰
4	且以青春赴山海，\n青舟无惧万重山。	青春本身就是利刃，可开山、可渡海；只要心怀远方，山再高、水再急，也挡不住少年出发的脚步。	理想信念、坚韧不拔、磨砺成长
5	他日卧龙终得雨，\n今朝放鹤且冲天。	无论“待机”抑或“起飞”，皆须自信——未来可期，此刻即行。	自我磨炼、积蓄力量
6	流水不争先，\n争的是滔滔不绝。	在人生的道路上，不应过于急功近利，而是要像流水一样保持持续不断的动力和韧性。它强调的是长期的坚持和不懈的努力，而不是短暂的领先或一时的风光。只有这样，才能在漫长的人生旅途中不断前进，最终达到目标。做人要像流水一样，不去争先后，不能靠一时性急，而是要脚踏实地，一点一点地积攒自己的力量，凡事讲究顺其自然，不要过分强求，不要过多地考虑功利。	踏实前进、追求梦想、坚持与成功、不急功近利、长期主义
7	纤纤不绝林薄成，\n涓涓不止江河生。	细小的丝线绵绵不绝，能织成茂密的树林；细小的水流源源不断，能汇成奔腾的江河。强调积少成多、持之以恒的力量。	积少成多、持之以恒、奉献与坚持
8	越不可越之山，\n渡不可渡之海。	指面对被公认为无法跨越的极限与绝境，仍以坚定信念与卓绝实践开辟新路，把“不可能”改写成“已到达”。	挑战极限、科技报国
9	怀鸿鹄之志，\n展骐骥之跃。	有鸿鹄那样远大的志向，展现骐骥般的飞跃。鼓励人们要有高远的志向和积极进取的精神。	志向抱负、奋斗进取、爱国奉献
10	没有一蹴而就的成功，\n只有厚积薄发的胜利。	成功从来不是一件一蹴而就的事情，成功路上，磨难是最普遍的事情，我们应该越挫越勇，而不是遇见一点风雨就选择放弃。	积累、挫折、信念、追梦
11	若你决定灿烂，\n山无遮，\n海无拦。	如果你决心要让自己的人生辉煌灿烂，那么无论是高山还是大海，都无法阻拦你。	坚定信念、追求梦想、勇往直前
1	安于现状，\n只会畏缩不前；\n创新迭代，\n才能勇往直前。	满足于当前状态会让人失去前进动力，唯有持续创新突破才能开辟新局。揭示发展需在动态中突破的核心规律。	创新驱动发展、突破与传承、动态成长
12	莫愁千里路，\n自有到来风。	不要为前路千里迢迢而忧愁，自会有顺风到来助力前行。传达出一种对未来充满信心，不必为路途遥远而担忧的乐观态度。	青年奋斗、乐观面对挫折、坚定信念
14	山月不知心里事，\n水风空落眼前花.	出自温庭筠《梦江南·千万恨》。每个人心中都有专属的“山月”与“水风”，那些未说出口的情愫、藏在心底的梦想，恰似山月不解心事、水风空落繁花，看似触手可及却难遂心愿。但这份遗憾与距离，从未困住前行的脚步，反而化作探索自我、超越局限的勇气，让每个平凡奋斗者在时代中书写不凡。	青春、梦想、坚毅
15	他人观花不涉你目，\n他人碌碌不涉你足。	他人看花，无须你的眼睛；他人忙碌，无须你的双脚。意指不为无关之事耗费心神，专注自身，不为外界纷扰所动。	保持专注、坚守目标、自律自省
16	欲度关山，何惧狂澜。\n风生水起，正好扬帆。	表达了一种勇往直前、无惧挑战的精神。关山象征艰难险阻，狂澜代表巨大的困难，而“风生水起，正好扬帆”则寓意在机遇与挑战并存时，抓住时机，勇敢启航。这句诗鼓励人们在面对困难时坚定信念，迎难而上，把握机遇，实现理想。	不畏艰险、勇敢拼搏、坚定信念
17	山长水阔不辞其远，\n赴汤蹈火不改其志。	表达了无论前方的道路有多么艰难险阻，都不能动摇一个人内心深处的决心和信念。它强调了面对挑战时的坚韧不拔，以及为了实现目标不惜付出任何代价的精神。	坚定信念、不畏艰难、执着追求
18	最慢的步伐不是跬步，\n而是徘徊；\n最快的脚步不是冲刺，\n而是坚持。	否定无效内耗，肯定持续行动的价值。徘徊犹豫比缓慢前进更消耗生命能量；真正的速度来自日复一日的坚持，而非短暂冲刺。	坚持、行动、拒绝内耗、自我成长
19	最好的伯乐，\n是努力的自己。	站在树上的不怕树枝断裂，因为它依赖的不是树枝，而是自己的翅膀；从今天起，把更多的时间拿来丰富自己，那些你看过的书、走过的路、见过的人、给出的善意最终都会回馈到自己身上。	自我成长、独立自强、内驱力、奋斗
20	有风有雨是常态，\n风雨无阻是心态，\n风雨兼程是状态。	将人生困境具象为“风雨”，提出三重境界：接受风雨必然性（常态），以无畏心面对（心态），在行动中穿越风雨（状态）。	人生态度、积极面对困境、奋斗精神、心态调整
21	乐观是最珍贵的心态。	生活总有阴天，但也总会放晴，真正厉害的人不是没有经历过低谷，而是跌倒了还能笑着爬起来，依然对未来充满希望；充满希望，才能向阳而生，心怀热忱，方能乘风破浪。	乐观心态、积极面对困境、人生态度
13	苦尽甘来终有时，\n一路向阳待花期。	道尽坚守的力量：那些独自跋涉的孤寂、逆风前行的艰难，都不会是终点。只要心怀暖阳、步履不停，待熬过风雨洗礼，所有付出终将化作甘甜，曾经期盼的美好，终会在时光里如期绽放。向未来张望的时光，或许孤独漫长，别放弃，等到苦尽甘来的那天，山河星月都做贺礼。你披星戴月走过的路终将会繁花遍地。	勇往直前、不惧风雨、坚韧不屈
23	山不让尘，川不辞盈。	大山不嫌弃微小的尘土所以成就了自己的雄伟高大，大海不害怕水多充溢才有了自己的宽广无垠。凡事要从点滴做起，不断积累，方能有所成就。	积累、包容、脚踏实地、厚积薄发
24	日出有盼，日落有思，\n平平安安，所遇皆甜。	只要日出就会有盼头，只要有日落就会有思念，祈祷大家平平安安，遇到的都是美好。	生活感悟、平安喜乐、珍惜当下、美好期许
25	在心里种花，\n人生才不会荒芜。	一个人的心中有理想，有希望，人生才能活得精彩，大自然的花香风景能让我们暂得舒畅，而心里的花香，却能给我们一世芬芳。一个人的心中有理想、有希望，人生才能活得精彩，大自然的花香风景能让我们暂得舒畅，而心里的花香，却能给我们一世芬芳。	理想与希望、内心丰盈、精神成长、人生态度
26	花会沿路盛开，\n你以后的路也是。	前路仍然有美好在等待着你，你一定要坚定住自己的信念，表达了前路不一定是坎坷的，告诫他人一定要坚持到底。因为花会沿路盛开，你不会一直遭遇困难的，只要你有坚定的决心，就能成功。	坚定信念、未来可期、坚持到底、美好期许
27	少年应当扶摇上，\n揽星衔月逐月光。	少年应该积极向上，胸怀壮志，追逐高远目标，去摘取星星、月亮，追逐美好的事物。少年应该积极向上，胸怀壮志，追逐高远目标，去摘取星星、月亮，追逐美好的事物。	追求梦想、青春、勇敢追梦、志存高远、无畏探索
28	一花独放不是春，\n百花齐放春满园。	只有一支花朵开放，不能算是春天来临；只有各种各样的花都开放了，满园都是春色，那才是真正的春天。现多用来比喻只有个人或者个别地区、单位发展进步是不够的，只有所有人、所有地区和单位共同进步，才能实现繁荣富强的局面。	团结共生、美美与共、共同进步、繁荣发展
29	万事从来贵有恒，\n久久为功事必成。	体现了一种积极向上的价值观和做事态度。它提醒人们在面对各种目标和任务时，不要急于求成，要有耐心和毅力。	坚持不懈、专注、坚韧、长期主义
30	树高千尺有根，\n江河万里有源。	树长得再高，也是因为有根来提供养分；江河奔腾万里，是因为有源头的水源源不断地汇聚。	不忘初心、感恩、坚守、寻根溯源、精神根基
31	少年没有乌托邦，\n心有远方自明朗。	少年心怀乌托邦，心向朝阳肆生长；少年应该有梦，不应处处心动，要付出行动；少年不应沮丧，青春本就疯狂一场，心之所向，或许就在前方。	青春梦想、励志奋斗、积极进取、志存高远
32	让花成花，让树成树。	让每个人都成为最好的自己，把自己还给自己，把别人还给别人，把孩子还给孩子，让孩子长成本来该长成的样子。让每个人都成为最好的自己，把自己还给自己，把别人还给别人，把孩子还给孩子，让孩子长成本来该长成的样子。出自杨绛先生经典语录。	尊重差异、自我价值、自信坚强、顺应天性、多元发展、生命独特、成就绚烂
34	物物而不物于物，\n念念而不念于念。	若你不怕失去，就不会被控制，反而你能更轻松的驾驭。不要害怕失去，你所失去的也许本来就不属于你。见过花开就好了，又何必在乎花是属于谁呢？	保持清醒、坚定信念、超脱得失、精神自由
33	没有一朵花，\n一开始就是花。	每一朵花都是从种子开始，经过种植、发芽、生根、浇水、成长，最终绽放出绚丽的花朵。这个过程与我们的人生相似，经历风雨洗礼，不断破局，不断充实自己成长的过程中，我们需要学会欣赏自己，独立坚强，珍惜时间，不辜负过去和未来，成为自己心中的花朵。	努力、坚强、时光、磨砺、成长、厚积薄发
35	山高自有客行路，\n水深自有渡船人。	山高自然会有行人的路，水深自然会有渡船的人。意思是无论遇到多大的困难，总会有办法解决。山高自然会有行人的路，水深自然会有渡船的人。意思是无论遇到多大的困难，总会有办法解决。	勇敢面对困难、信念与坚持、绝境逢生
36	风劲帆满海天远，\n鼓角争鸣踏征程。	人生就像一场航行，我们每个人都是一艘船，面对未知的海洋和变幻莫测的风浪，需要有坚定的方向和不屈的精神。只有在风劲帆满之时，勇敢地扬帆启航，才能到达理想的彼岸。	勇敢拼搏、追求梦想、开拓创新、砥砺前行、时代担当
37	羡子年少正得路，\n有如扶桑初日生。	表达了对年轻人的羡慕和赞美，认为他们正值青春年华，充满活力和希望，如同初升的太阳，光芒四射，前途无限。它强调了青春时期的宝贵和美好，以及年轻人身上所蕴含的巨大潜力。	青春奋斗、少年风采、未来可期、朝气蓬勃
38	历尽天华成此景，\n人间万事出艰辛。	经历了种种的艰辛和磨难，才成就了如今这般美好的景象，人世间的任何事情，都是要付出艰辛的努力才能成功的。经历了种种艰难困苦才成就了如今的美好景象，世间的任何事情都是从艰辛中得来的。 适用范围：砥砺前行、梦想与追求、青年奋斗、苦难与成长、坚持与奋斗、克服困难、成就与付出、逆境坚守、逐梦前行	
39	青年需怀凌云志，\n直从平地起千寻。	青年人应当怀有高远宏大的志向，凭借着这份志向，即便是从平凡的起点出发，也能够不断向上攀升，达到极高的成就。	青年奋斗、青年担当、追求梦想、志存高远、脚踏实地
40	好事尽从难处得，\n少年无向易中轻。	好事、成功的事情都是从艰难困苦中得来的，年轻人不要去选择容易的事情而轻视那些具有挑战性的事情，告诫少年应勇于面对困难，在艰难中成就好事。	青年奋斗、不畏艰险、少年壮志、迎难而上
41	苍山负雪，明烛天南。	象征着在困难和挑战面前，人们应该像泰山样，不畏艰难，勇往直前，同时也表达了人们对美好未来的向往和追求。	直面苦难、挫折、坚持、家国情怀、矢志不渝
42	当为秋霜，无为槛羊。	应当成为秋霜而不是被关在栅栏里的羊。比喻做人要有气节，不向恶势力屈服，不做任人率割的对象。	坚守气节、追求正义、独立人格、刚正不阿、精神风骨
43	燕雀终成鲲鹏日，\n不在今朝在万里。	平凡之人亦能成就非凡伟业，但成功并非一蹴而就，而是需要长期的积累与奋斗。	青年奋斗、坚定信念、追逐梦想、长期主义、厚积薄发
44	玉经琢磨多成器，\n剑拔沉埋便倚天。	寓意着经过磨砺与沉淀，方能成就非凡。玉石经过雕琢才能成为珍宝，利剑经过锤炼才能锋芒毕露。	砥砺前行、坚定信念、青年奋斗、磨砺成长、厚积薄发
45	心至苍穹外，\n目尽星河远。	描绘了一种超越世俗、志向高远的境界。心之所向，直达天际；目光所及，跨越星河。它象征着人类对未知的无限探索与追求，体现了不畏艰难、勇攀高峰的精神。	青年奋斗、坚定信念、追求梦想、探索未知、志存高远
46	鹤别青山，不见桃花。	白鹤告别了空山（青山），（今春）再也看不见桃花。一旦离开了某种环境，可能就会错失一些美好，徒留遗憾和伤感。也有逝者如斯、转眼斗转星移，物是人非之意。	离别之苦、人生无常、命运多舛、物是人非、珍惜当下
22	追风赶月莫停留，\n平芜尽处是春山。	拼搏的时候，不要迷恋旅途的风景。追求目标的时候，千万不要停留，即便与目标还有重重阻碍，努力终有回报，春山就在平芜的尽头。一路追逐着风、追赶着月亮，不要停下脚步，在那平坦的草地尽头，是云零缭绕的春山。寓意着在追求理想的道路上不要半途而废，坚持下去就能看到美好的前景。	坚持奋斗、追逐梦想、勇往直前
48	不能胜寸心，\n安能胜苍穹。	如果连自己的心都控制不住，怎么能够战胜客观世界。出自清人龚自珍《白春组秋·偶有所触》。	坚守理想、坚定信念、自我控制、修身律己、扎根实干
49	世人皆道歧路难，\n我沿歧路向高山。	世人说岔路难行，我偏偏把歧路当登山路——不惧众议，独辟蹊径，逆势而上。	独立思考、逆境突围、独辟蹊径、逆势成长、行者自高
50	涉浅滩者得鱼虾，\n入深水者得蛟龙。	在浅水中只能捕到鱼虾，在深水中才能捕得蛟龙。比喻付出多大的劳动，才会有多大的收获。	深耕、深究、艰辛、努力、价值、深入探索、自我实现
51	肩鸿任钜踏歌行，\n功不唐捐玉汝成。	肩鸿任钜踏歌行，功不唐捐玉汝成。世界上的所有功德与努力，都是不会白白付出的，必然是有回报的。出处是《法华经》和宋代·张载的《西铭》。	青年、家国情怀、责任担当、奋斗实干、功不唐捐
52	且持梦笔书奇景，\n日破云涛万里红。	且拿着梦想这支笔来书写奇特的景象，终有一天太阳会冲破云涛，映出万里红色的光辉。寓意着要心怀梦想去创造美好，终会迎来成功和光明。	积极乐观、坚强不屈、心怀希望、以梦为笔、逐梦前行
53	总有人间一两风，\n填我十万八千梦。	该来的总会来，人生尽管充满了不如意，但那些属于你的辉煌与美好终将在某一刻如约而至。明天的片刻，都足以让我在那之前，梦过想过千万遍，因为明天约好和你见面。即便是彼时一两的风在我心中也弥足重要很有分量。	梦想、现实、理想、积极向上、珍惜美好
54	寄蜉蝣于天地，\n渺沧海之一粟。	出自北宋苏轼《赤壁赋》，生动描绘了个体生命的短暂与宇宙的浩瀚无垠。人类如同天地间的蜉蝣，生命短暂而微不足道；又似沧海中的一粒沙砾，渺小到几乎可以忽略不计。这句话不仅是对自然界的感慨，也是对人生意义的深刻反思。	平凡生活、积极向上、珍惜时间、创造价值、汇聚力量
55	当晦暗散尽，\n终星河长明。	当一些不好的事情都过去之后，终究会看到希望。今日过后，所有的晦暗都留给过往。凛冬散尽，星河长明。愿往后日子，日光温和，山风温柔拥抱你。	青年、奋斗、梦想、心怀希望、冲破阴霾
56	梅须逊雪三分白，\n雪却输梅一段香。	梅花虽艳不及雪的洁白，雪花虽纯难比梅的清香，万物各有长短，彼此映衬方得完整。	接纳差异之美、各展所长、共生共荣、长短相济、多元共存
57	大知闲闲，小知间间。	拥有大智慧的人能够从宏观的角度看待问题、不被眼前的困难所束缚，从而做出更加明智的选择。相反，那些缺乏远见的人则容易被琐事牵绊，难以突破自我。	豁达胸怀、逆境不屈、提升思想、保持清醒、拥抱美好
58	以不息为体，\n以日新为道。	寓意着持之以恒的奋斗精神与持续不断的创新意识。不息是指永不停歇的努力，日新则代表每天都有新的进步和发展。这一理念鼓励人们始终保持积极向上的态度，不断追求自我超越，实现个人和社会的共同进步。	奋斗、自我成长、积极向上、创新突破、民族复兴
59	不登高山，\n不知天之高也；\n不临深溪，\n不知地之厚也。	如果不登上高山，就不会知道天空是多么的辽阔；如果不亲临深谷，也无法体会到大地的深厚。这句话寓意着实践出真知，亲身经历才能获得深刻的认识。	青春、梦想、进取创新、迎接挑战、实践真知
60	一身报国有万死，\n双鬓向人无再青。	这句诗如同一面镜子，映照出无数中华儿女舍小家为大家的伟大形象。在国家危难之际，他们挺身而出，不计个人得失，只求国家安宁。这种精神穿越时空，激励着一代又一代的中国人，无论身处何方，都应当时刻铭记自己的根与魂，将个人命运与国家兴衰紧密相连。	家国情怀、责任担当、面对挫折、赤子之心、忠诚热爱
\.


--
-- Data for Name: video; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.video (device, url) FROM stdin;
default	http://0.0.0.0/test/video.mp4
\.


--
-- Name: days_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.days_master_id_seq', 2, true);


--
-- Name: renmindaily_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.renmindaily_id_seq', 60, true);


--
-- Name: config config_device_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_device_key_key UNIQUE (device, key);


--
-- Name: days_master days_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.days_master
    ADD CONSTRAINT days_master_pkey PRIMARY KEY (id);


--
-- Name: device_list device_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_list
    ADD CONSTRAINT device_list_pkey PRIMARY KEY (device_id);


--
-- Name: notice_picture notice_picture_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notice_picture
    ADD CONSTRAINT notice_picture_pkey PRIMARY KEY (url);


--
-- Name: notice_text notice_text_device_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notice_text
    ADD CONSTRAINT notice_text_device_title_key UNIQUE (device, title);


--
-- Name: renmindaily renmindaily_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.renmindaily
    ADD CONSTRAINT renmindaily_pkey PRIMARY KEY (id);


--
-- Name: video video_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_pkey PRIMARY KEY (url);


--
-- PostgreSQL database dump complete
--

\unrestrict gkT8M6jp9xfbT0guBNnqMXoMeb7abAb9GXXKFBNf4N017tUmCH2lXxxOrWk2FAT

